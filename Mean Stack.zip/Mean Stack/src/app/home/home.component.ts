import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
import{FormControl} from '@angular/forms';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  name="omi";
  selectedfile=new FormControl('');
  filepath=this.selectedfile.value;


  constructor(private router:Router,private http:HttpClient) { }
onFileSelected(event){
  //console.log(event);
  this.selectedfile=event.target.files[0];
}

  ngOnInit(): void {
     alert("Welcome !!!! Design your Own Image");
    if (!sessionStorage.getItem('sid')) {
      this.router.navigate(['login']);
    }
  }
  logout(){
  sessionStorage.removeItem('sid');
     this.router.navigate(['login']);
  }

}
