import { Component, OnInit } from '@angular/core';
import{FormBuilder, Validators,FormGroup} from '@angular/forms';
//import { MustMatch } from './_helpers/must-match.validator';

import{HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-page4',
  templateUrl: './page4.component.html',
  styleUrls: ['./page4.component.css']
})
export class Page4Component implements OnInit {
  formgroup=this.formgroupb.group({
    username:['',[Validators.required,Validators.minLength(5)]],//,Validators.pattern('[A-Za-z]')
    email:['',Validators.required],
    mobno:['',Validators.required],
    password:['',[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')
  ]],
    repassword:['',Validators.required]

  })

  


public expression=false;
credential=false;

  constructor(private formgroupb:FormBuilder,private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  }
  
async getdata(){
let data=this.formgroup.value;
console.log(this.formgroup.value)
  let url='http://localhost:3000/user';
let result:any=  await this.http.post(url,data).toPromise();
  
this.credential=true;
if(result.operation){
    
    this.formgroup.reset();
  }
  
this.credential=true;
 
 
}
}
