import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{ReactiveFormsModule} from '@angular/forms';
import{ HttpClientModule }from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Page1Component } from './page1/page1.component';
import { Page2Component } from './page2/page2.component';
import { Page3Component } from './page3/page3.component';
//import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { Page4Component } from './page4/page4.component';
import { HomeComponent } from './home/home.component';

//import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
//import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
//import { AppComponent } from './app.component';
//import { DialogModule } from '@syncfusion/ej2-angular-popups';

@NgModule({
  declarations: [
    AppComponent,
    Page1Component,
    Page2Component,
    Page3Component,
    Page4Component,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
  //RichTextEditorAllModule,
    //DialogModule
  //  FontAwesomeModule,
  //  NgxQuillModule ,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
