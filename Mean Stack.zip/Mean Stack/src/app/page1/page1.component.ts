import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormControl, Validators, FormGroup} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component implements OnInit {
 public credential= false;
  
  formgroup=this.form_b.group({
    email:['',Validators.required],
    password:['',Validators.required]
    
  });

  constructor(private form_b:FormBuilder,private http:HttpClient,private router:Router) { }



  ngOnInit(): void {
  }
  async getdata(){

    let userdata=this.formgroup.value;
    let url='http://localhost:3000/userdata';
    let data:any=await this.http.post(url,userdata).toPromise();
  
   if(data.operation){
     sessionStorage.setItem('sid','true');
     
    this.router.navigate(['home']);
    }
   else{
    this.credential=true;
   }
    this.formgroup.reset();
  }

}
