import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormControl, Validators, FormGroup} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-page2',
  templateUrl: './page2.component.html',
  styleUrls: ['./page2.component.css']
})
export class Page2Component implements OnInit {
  success=false;
  alert=false;
  formgroup=this.form_b.group({
    username:['',Validators.required],
    password:['',[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')
  ]],
    Repassword:['',Validators.required],

  });

  constructor(private form_b:FormBuilder,private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  }
  async resetpass(){
    //console.log(this.formgroup.value);
    let data=this.formgroup.value;
    let url="http://localhost:3000/update";
    let result:any=await this.http.post(url,data).toPromise();
    
    if(result.operation){
      this.success=true;
    }
    else{
      this.alert=true;
    }
    this.formgroup.reset();
  }

}
