import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import{ HttpClient }from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'angular';
  list:any=[];
 constructor(private http:HttpClient){}
 ngOnInit(): void {
this.ajaxcall();
}


async ajaxcall(){
  let url="http://localhost:1000/userdata";
  let data=await this.http.get(url).toPromise();
this.list=data;
console.log(data);
}
}
