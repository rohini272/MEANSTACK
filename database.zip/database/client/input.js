let senddata1=()=>{
    console.log("omi"); 
    let a=document.querySelector("#input").value;
 let b=document.querySelector("#password").value;

 let url=`http://localhost:1000/userdata?username=${a}&password=${b}`;

    let xhr=new XMLHttpRequest();
     xhr.open("Get",url);
     xhr.onload=()=>{
         const res=xhr.responseText;
         //console.log(res);
         document.querySelector("#input").value="";
         document.querySelector("#password").value="";
     };
     xhr.send();
 //console.log(url);
}

let senddata2=async()=>{
    let a=$("#input").val();
    let b=$("#password").val();
    //console.log(a);
    let url=`http://localhost:1000/userdata?username=${a}&password=${b}`;
    const data=await fetch(url);
    const res=data.json();
    console.log(res);
    $("#input").val()="";
    $("#password").val()="";
}

let senddata=async()=>{
    let username=$("#input").val();
    let password=$("#password").val();

    let url="http://localhost:1000/user";

    let userdata={username,password};
   await fetch(url,{method:"post" ,body:JSON.stringify(userdata),headers:{"Content-Type": "application/json"}});

    $("#input").val()="";
    $("#password").val()="";
}

