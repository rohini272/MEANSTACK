let data_config ={host:"localhost",
                user:"root",
                password:"Onkar@1495",
                database:"mean"
                    }
module.exports=data_config;