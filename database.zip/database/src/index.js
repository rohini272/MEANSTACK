const express=require("express");
const database=require("./database");
const cors=require("cors");
const app=express();
app.use(cors());
app.use(express.json());

app.get("/omi",async(req,res)=>{
   try{ 
     //let list =req.query;
  //await database.getdata(list);
  // let result =await database.getdata();
  
  res.json(result);
   }
   catch(err){
     res.json("server fail");
   }

});

app.post("/userdata",async(req,res)=>{
try{
  await database.getdata(req.body);
 res.json({operation:true});

}
catch(err){
  res.json({operation:false});
  //res.json(err);
}
});

app.post("/user",async(req,res)=>{
  try{
    await database.adddata(req.body);
   res.json({operation:true});
  
  }
  catch(err){
    res.json({operation:false});
    //res.json(err);
  }
  });

app.post("/update",async(req,res)=>{
    try{
      await database.updatedata(req.body);
     res.json({operation:true});
    
    }
    catch(err){
      res.json({operation:false});
    }
    });

app.listen(3000);
  