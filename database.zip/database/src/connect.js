const Promise= require('bluebird');
const mysql= require('mysql');
let data_config=require('./data_config');


Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let getdata=async()=>{
    try{
    let connection=mysql.createConnection(data_config);
    //console.log("hello");
    await connection.connectAsync();

    //let data="insert into person(user_id,username,email_id,mobno,password)values(?,?,?,?,?)";
    //let data="update person set mobno=112233445566 where username=?and user_id=?";
   // let data="update person set  username=? where user_id=?";
    //let data="select * from ??,?? where ??=??";
    let data="select * from user";
   //let result= await connection.queryAsync(data,[4,"dipeshchoudhari","dipeshc@gmail.com","12345689","dip@12345"]);
   // let result= await connection.queryAsync(data,["person","Employee","user_id","id"]);
        let result=await connection.queryAsync(data);
    await connection.endAsync();
    console.log(result);
    return result;
    }
    catch(err){
        console.log(err);
    }
}

getdata();