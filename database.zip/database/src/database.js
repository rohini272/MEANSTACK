const Promise= require('bluebird');
const mysql= require('mysql');
let data_config=require('./data_config');


Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let getdata=async(user)=>{

    let connection=mysql.createConnection(data_config);
    await connection.connectAsync();

   
   let data="select email,password from userdata where email=? and password=?";
        let result=await connection.queryAsync(data,[user.email,user.password]);
        await connection.endAsync();
    //return ;
    if(result.length===0){
        throw new Error("Invalid Credentials");
    }
    

};
let adddata=async (user)=>{
    
        let connection=mysql.createConnection(data_config);
        await connection.connectAsync();
    
       
       let data="insert into userdata(username,email,mobno,password) values(?,?,?,?)";
            let result=await connection.queryAsync(data,[user.username,user.email,user.mobno,user.password]);
            await connection.endAsync();

        if(result.length===0){
            throw new Error("Invalid Credentials");
        }
        
        
    }
    let updatedata=async (user)=>{
    
        let connection=mysql.createConnection(data_config);
        await connection.connectAsync();
    
       
       let data="update userdata set password=? where username=?";
            let result=await connection.queryAsync(data,[user.password,user.username]);
            await connection.endAsync();

        if(result.length===0){
            throw new Error("Invalid Credentials");
        }
        
        
    }

module.exports={getdata,adddata,updatedata};